import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;

public class LibraryGUI extends JFrame {
    private ArrayList<Book> books;
    private JTextArea bookDisplay;
    private JTextField titleField, authorField, searchField;
    private final String FILE_NAME = "books.txt";

    public LibraryGUI() {
        books = new ArrayList<>();
        loadBooksFromFile();
        setTitle("📚 Library Management System");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(240, 248, 255));

        // Input Panel
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Book Information"));
        inputPanel.setBackground(new Color(224, 255, 255));

        inputPanel.add(new JLabel("Book Title:"));
        titleField = new JTextField();
        inputPanel.add(titleField);

        inputPanel.add(new JLabel("Author:"));
        authorField = new JTextField();
        inputPanel.add(authorField);

        JButton addButton = new JButton("➕ Add Book");
        JButton updateButton = new JButton("✏️ Update Book");
        inputPanel.add(addButton);
        inputPanel.add(updateButton);
        add(inputPanel, BorderLayout.NORTH);

        // Display Panel
        bookDisplay = new JTextArea();
        bookDisplay.setEditable(false);
        bookDisplay.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(bookDisplay);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Book List"));
        add(scrollPane, BorderLayout.CENTER);

        // Search Panel
        JPanel searchPanel = new JPanel();
        searchPanel.setBackground(new Color(240, 255, 240));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Search / Actions"));

        searchField = new JTextField(15);
        JButton searchButton = new JButton("🔍 Search");
        JButton viewAllButton = new JButton("📖 View All");
        JButton deleteButton = new JButton("🗑️ Delete");

        searchPanel.add(new JLabel("Search by Title:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        searchPanel.add(viewAllButton);
        searchPanel.add(deleteButton);
        add(searchPanel, BorderLayout.SOUTH);

        // Button Listeners
        addButton.addActionListener(e -> addBook());
        updateButton.addActionListener(e -> updateBook());
        deleteButton.addActionListener(e -> deleteBook());
        searchButton.addActionListener(e -> searchBook());
        viewAllButton.addActionListener(e -> viewBooks());

        setVisible(true);
    }

    private void addBook() {
        String title = titleField.getText();
        String author = authorField.getText();
        if (!title.isEmpty() && !author.isEmpty()) {
            books.add(new Book(title, author));
            saveBooksToFile();
            JOptionPane.showMessageDialog(this, "✅ Book added successfully!");
            titleField.setText("");
            authorField.setText("");
            viewBooks();
        } else {
            JOptionPane.showMessageDialog(this, "⚠️ Please fill in both fields.");
        }
    }

    private void updateBook() {
        String searchTitle = searchField.getText().toLowerCase();
        for (Book book : books) {
            if (book.getTitle().toLowerCase().equals(searchTitle)) {
                book.setTitle(titleField.getText());
                book.setAuthor(authorField.getText());
                saveBooksToFile();
                JOptionPane.showMessageDialog(this, "✅ Book updated.");
                viewBooks();
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "❌ Book not found to update.");
    }

    private void deleteBook() {
        String searchTitle = searchField.getText().toLowerCase();
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getTitle().toLowerCase().equals(searchTitle)) {
                books.remove(i);
                saveBooksToFile();
                JOptionPane.showMessageDialog(this, "🗑️ Book deleted.");
                viewBooks();
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "❌ Book not found to delete.");
    }

    private void viewBooks() {
        bookDisplay.setText("");
        for (Book book : books) {
            bookDisplay.append(book + "\n");
        }
    }

    private void searchBook() {
        String keyword = searchField.getText().toLowerCase();
        bookDisplay.setText("");
        for (Book book : books) {
            if (book.getTitle().toLowerCase().contains(keyword)) {
                bookDisplay.append(book + "\n");
            }
        }
    }

    private void saveBooksToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Book book : books) {
                writer.write(book.getTitle() + "," + book.getAuthor());
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "❌ Error saving books.");
        }
    }

    private void loadBooksFromFile() {
        books.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",", 2);
                if (data.length == 2) {
                    books.add(new Book(data[0], data[1]));
                }
            }
        } catch (IOException e) {
            // Ignore if file doesn't exist yet
        }
    }
}